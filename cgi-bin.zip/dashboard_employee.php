<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
$role = strtolower(trim($_SESSION['role'] ?? ''));
if ($role !== 'admin' && $role !== 'manager') {
    header("Location: login.php");
    exit;
}
?>
<h2>Welcome <?= htmlspecialchars($_SESSION['name']) ?> (<?= htmlspecialchars($_SESSION['role']) ?>)</h2>
<p>This is the employee dashboard. You are either a manager or an admin.</p>
<a href="logout.php">Logout</a>

