<?php
session_start();
include'db.php';
ini_set('display_errors',1);
error_reporting(E_ALL);

$sql = "SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON p.category_id";
$result = $conn->query($sql);
if(!$result){
    echo "SQL Error: " . $conn->error;
    exit;
}
?>
<h2>Welecome to Snickers Universe</h2>
<?php if (isset($_SESSION['name'])): ?>
<p>Logged in as <?= htmlspecialchars($SESSION['name']) ?> (<?= $_SESSION['role'] ?>)</p>
<?php endif; ?>
<hr>
<?php while ($row = $result->fetch_assoc()): ?>
<div style="border:1px solid #ccc; padding:10px; margin:10px;">
    <h3><?= htmlspecialchars($row['name']) ?></h3>
    <p>Category: <?= htmlspecialchars($row['category_name']) ?></p>
    <p><?= htmlspecialchars($row['description']) ?></p>
    <p><strong>$<?= number_format($row['price'], 2) ?></strong></p>
    <?php if (!empty($row['image_url'])): ?>
    <img src="<?= htmlspecialchars($row['image_url']) ?>" width="100">
    <?php endif; ?>
    <form method="post" action="cart.php">
<input type= "hidden" name="product_id" value="<?= $row['product_id']?>">
<input type="number" name="quantity" value="1" min="1">
<button type"submit" name="add_to_cart">Add to cart</button>
</form>
</div>
<?php endwhile;?>
