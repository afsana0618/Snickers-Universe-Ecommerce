<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'], $_POST['product_id'], $_POST['quantity'])){
    $product_id = intval($_post['product_id'];
    $quantity = intval($_POST['quantity']);
    $stmt = $conn->prepare("SELECT name, price FROM products WHERE product_id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1){
        $product = $result->fetch_assoc();
        if(!isset($_SESSION['cart'])){
            $_SESSION['cart'] = [];
        }
        if (isset($_SESSION['cart'][$product_id])){
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        }else{
            $_SESSION['cart'][product_id]=[
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity];
        }
    }
}
header("Location: shop.php");
exit;