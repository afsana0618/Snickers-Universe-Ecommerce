<?php
session_start();
ini_set('display_errors',1);
error_reporting(E_ALL);
include 'db.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT user_id AS id, first_name, password, 'user' AS role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user_result = $stmt->get_result();
    if ($user_result->num_rows === 1) {
        $row = $user_result->fetch_assoc();
    } else {
        $stmt = $conn->prepare("SELECT employee_id AS id, first_name, password, role FROM employee WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $emp_result = $stmt->get_result();
        if ($emp_result->num_rows === 1) {
            $row = $emp_result->fetch_assoc();
        } else {
            $error = "User not found.";
        }
    }
    if (!empty($row)) {
        if ($password === $row['password']) { 
            $_SESSION['id'] = $row['id'];
            $_SESSION['name'] = $row['first_name'];
            $_SESSION['role'] = strtolower(trim($row['role']));
            if ($_SESSION['role'] === 'user') {
                header("Location: dashboard_user.php");
                exit;
            } elseif ($row['role'] === 'Admin') {
                header("Location: dashboard_employee.php");
                exit;
            } elseif ($row['role'] === 'Manager') {
                header("Location: dashboard_employee.php");
                exit;
            } else {
                $error = "Unrecognized role.";
            }
            exit();
        } else {
            $error = "Incorrect password.";
        }
    }
}
?>
<h2>Login</h2>
<form method="post">
    <input type="email" name="email" placeholder="Email" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    <button type="submit">Login</button>
</form>
<p style="color:red"><?= $error ?></p>
