<?php
session_start();
include 'db.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Handle empty cart
echo "<h2>Your Shopping Cart</h2>";
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "<p>Your cart is empty.</p>";
    exit;
}

// Step 1: Gather product IDs
$product_ids = array_keys($_SESSION['cart']);
$placeholders = implode(',', array_fill(0, count($product_ids), '?'));

// Step 2: Prepare query
$sql = "SELECT product_id, name, price FROM products WHERE product_id IN ($placeholders)";
$stmt = $conn->prepare($sql);

// Step 3: Bind parameters with compatibility support
function refValues($arr) {
    if (strnatcmp(phpversion(), '5.3') >= 0) {
        $refs = [];
        foreach ($arr as $key => $value) {
            $refs[$key] = &$arr[$key];
        }
        return $refs;
    }
    return $arr;
}

$types = str_repeat('i', count($product_ids));
$params = array_merge([$types], $product_ids);
call_user_func_array([$stmt, 'bind_param'], refValues($params));

// Step 4: Execute and fetch product data
$stmt->execute();
$result = $stmt->get_result();
$products = [];
while ($row = $result->fetch_assoc()) {
    $products[$row['product_id']] = $row;
}

// Step 5: Display cart
$total = 0;
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Product</th><th>Quantity</th><th>Price</th><th>Subtotal</th></tr>";

foreach ($_SESSION['cart'] as $id => $qty) {
    if (!isset($products[$id])) continue;
    $name = htmlspecialchars($products[$id]['name']);
    $price = $products[$id]['price'];
    $subtotal = $price * $qty;
    $total += $subtotal;

    echo "<tr>
            <td>$name</td>
            <td>$qty</td>
            <td>$$price</td>
            <td>$$subtotal</td>
          </tr>";
}

echo "<tr><td colspan='3'><strong>Total:</strong></td><td><strong>$$total</strong></td></tr>";
echo "</table>";

echo "<br><a href='shop.php'>Continue Shopping</a>";
?>









